const productionModelsModule = {
  namespaced: true,
  state: {
    modelName: "",
  },

  mutations: {
    changeName(state,val) {
      state.modelName = val;
    }
  },

  actions: {
    changeModelName({ commit }, val) {
      commit("changeName",val)
    },
    getModelName({state}){
        return state.modelName
    }
  },

  getters: {
    modelNmae: state => !!state.modelName,

  }
};

export default productionModelsModule;
