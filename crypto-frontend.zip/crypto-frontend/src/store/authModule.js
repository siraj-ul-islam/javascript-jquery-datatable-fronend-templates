import axios from 'axios';
import swal from "sweetalert2";

const authModule = {
  namespaced: true,
  state: {
    // status: "",
    token: localStorage.getItem("token") || "",
    // user: {},
    // fullname : localStorage.getItem('fullname') || "",
  },

  mutations: {
    auth_request(state) {
      state.status = "loading";
    },
    auth_success(state, {token}) {
      // state.status = "success";
      state.token = token;
      // state.user = user;
      // state.fullname = user.fullname;
      // console.log('in here');
      // console.log(user);
    },
    auth_error() {
      // state.status = "error";
    },
    logout(state) {
      state.status = "";
      state.token = "";
    }
  },

  actions: {
    login({ commit }, data) {
      // console.log(data)
      return new Promise((resolve, reject) => {
        commit("auth_request");
        axios({
          url: "http://34.207.113.52:8000/login",
          data,
          method: "POST"
        })
          .then(resp => {
            console.log(resp)
            if(resp.status == 200){
              const token = resp.data.access_token;
              // const user = resp.data.user;
              localStorage.setItem("token", token);
              // localStorage.setItem("user", JSON.stringify(user));
              // localStorage.setItem("fullname", user.fullname);
              axios.defaults.headers.common["Authorization"] = token;
              commit("auth_success", {token});
              resolve(resp);
            }else{
              swal.fire({
                title: resp.data.message,
                buttonsStyling: false,
                icon: "warning",
                customClass: {
                  confirmButton: "btn btn-danger btn-fill"
                }
              });
            }
          })
          .catch(err => {
            commit("auth_error");
            localStorage.removeItem("token");
            // localStorage.removeItem("user");
            reject(err);
          });
      });
    },
    register({ commit }, user) {
      return new Promise((resolve, reject) => {
        commit("auth_request");
        axios({
          url: "http://localhost:3001/api/auth/register",
          data: user,
          method: "POST"
        })
          .then(resp => {
            // const token = resp.data.token;
            // const user = resp.data.user;
            // localStorage.setItem("token", token);
            // axios.defaults.headers.common["Authorization"] = token;
            // commit("auth_success", token, user);
            resolve(resp);
          })
          .catch(err => {
            swal.fire({
              title: err.response.data.message,
              buttonsStyling: false,
              icon: "error",
              customClass: {
                confirmButton: "btn btn-danger btn-fill"
              }
            });
            commit("auth_error", err);
            localStorage.removeItem("token");
            localStorage.removeItem("user");
            reject(err);
          });
      });
    },
    forgetPassword(user){
      return new Promise((resolve, reject) => {
        // commit("auth_request");
        axios({
          url: "http://localhost:3001/api/auth/forgetPassword",
          data: user,
          method: "POST"
        })
          .then(resp => {
            resolve(resp);
          })
          .catch(err => {
            reject(err);
          });
      });
    },
    logout({ commit }) {
      return new Promise((resolve,reject) => {
        axios({
          url: "http://localhost:3001/api/auth/logout",
          data: {user: localStorage.getItem('user')},
          method: "POST"
        })
            .then(resp => {
              if(resp.data.status === 'success'){
                commit("logout");
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                localStorage.removeItem("fullname");
                // const token = '';
                // const user = {};
                delete axios.defaults.headers.common["Authorization"];
                resolve(true);
              }else{
                swal.fire({
                  title: resp.data.message,
                  buttonsStyling: false,
                  icon: "warning",
                  customClass: {
                    confirmButton: "btn btn-danger btn-fill"
                  }
                });
              }
            })
            .catch(err => {
              commit("auth_error");
              localStorage.removeItem("token");
              localStorage.removeItem("user");
              reject(err);
            });
      });
    }
  },

  getters: {
    isLoggedIn: state => !!state.token,
    authStatus: state => state.status,
    getToken : state => state.token
  }
};

export default authModule;
