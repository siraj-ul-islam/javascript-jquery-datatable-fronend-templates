import axios from 'axios';

const instance = axios.create({
  // http://34.207.113.52:8000/forecast/get/2022-03-1/2022-03-10
  baseURL: 'http://34.207.113.52:8000'
});
export default instance;
