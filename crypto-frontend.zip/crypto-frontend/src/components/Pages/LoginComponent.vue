<template>
  <div class="wrapper">
    <!--start page wrapper -->
    <div class="row">
      <div class="col-xl-12">
        <div class="border-top border-0 border-4">
          <div class="card-body p-20">
            <div class="card-title text-center">
              <img
                src="../../assets/images/logo.png"
                class="logo-login"
                alt="logo"
              />
              <h5 class="mb-5 mt-2 text-white">Login</h5>
            </div>
            <div class="col-xl-4 mx-auto">
              <ValidationObserver>
                <form class="form_row g-3" @submit.prevent="submit">
                  <div class="col-12">
                    <label for="inputLastEnterUsername" class="form-label"
                      >Enter Username</label>
                    <ValidationProvider
                      name="email"
                      rules="required"
                      v-slot="{ errors }"
                    >
                      <div class="input-group input-group-lg">
                        <span class="input-group-text"
                          ><i class="bx bxs-user"></i
                        ></span>
                        <input
                          type="text"
                          v-model="email"
                          class="form-control border-start-0 custom"
                          id="inputLastEnterUsername"
                          placeholder="Enter Username"
                        />
                        <span class="error-color">{{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-12">
                    <label for="inputLastEnterPassword" class="form-label"
                      >Enter Password</label
                    >
                    <ValidationProvider
                      name="password"
                      rules="required|min:5"
                      v-slot="{ errors }"
                    >
                      <div class="input-group input-group-lg">
                        <span class="input-group-text"
                          ><i class="bx bxs-lock-open"></i
                        ></span>
                        <input
                          type="password"
                          v-model="password"
                          class="form-control border-start-0"
                          id="inputLastEnterPassword"
                          placeholder="Enter Password"
                        />
                        <span class="error-color">{{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-12">
                    <div class="d-grid">
                      <button type="submit" class="btn btn-light btn-lg px-5">
                        <i class="bx bxs-lock-open"></i>Login
                      </button>
                    </div>
                  </div>
                </form>
              </ValidationObserver>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { ValidationObserver, ValidationProvider, extend } from "vee-validate";
import * as rules from "vee-validate/dist/rules";
import swal from "sweetalert2";
Object.keys(rules).forEach((rule) => {
  extend(rule, rules[rule]);
});

export default {
  name: "LoginComponent",
  components: {
    ValidationObserver,
    ValidationProvider,
  },
  data() {
    return {
      email: "",
      password: "",
      subscribe: true,
    };
  },
  methods: {
    async submit() {
      var formData = new FormData();
      formData.append("username", this.email);
      formData.append("password", this.password);
      try {
        let response = await this.$store.dispatch("auth/login", formData);
        console.log(response);
        if (response.status === 200) {
          this.$router.push("/dashboard");
        } else {
          swal.fire({
            title: "Username or Password is incorrect.",
            buttonsStyling: false,
            customClass: {
              confirmButton: "btn btn-success btn-fill",
            },
          });
        }
      } catch (error) {
        swal.fire({
            title: error.response.data.detail,
            buttonsStyling: false,
            customClass: {
              confirmButton: "btn btn-success btn-fill",
            },
          });
      }
    },
  },
};
</script>
<style>
.error-color {
  color: red;
}
.input-group-lg > span {
  width: 91%;
}
.input-group-text {
  width: 56px !important;
}
.border-start-0 {
  border-left: 0 !important;
  height: auto;
  padding: 13px !important;
  border-radius: 3px !important;
  color: #fff !important;
}
input,
textarea {
  background-color: transparent;
  border: solid 1px #fff6;
  border-radius: 2px;
  padding: 5px;
  color: #fff;
  font-size: 13px;
}
.row {
  --bs-gutter-x: 1.5rem;
  --bs-gutter-y: 0;
  display: flex;
  flex-wrap: wrap;
  margin-top: calc(-1 * var(--bs-gutter-y));
  margin-right: calc(-0.5 * var(--bs-gutter-x));
  margin-left: calc(-0.5 * var(--bs-gutter-x));
}
.form_row {
  --bs-gutter-x: 1rem;
  --bs-gutter-y: 1rem;
  display: flex;
  flex-wrap: wrap;
  margin-top: calc(-1 * var(--bs-gutter-y));
  margin-right: calc(-0.5 * var(--bs-gutter-x));
  margin-left: calc(-0.5 * var(--bs-gutter-x));
}
.form_row > * {
  flex-shrink: 0;
  width: 100%;
  max-width: 100%;
  padding-right: calc(var(--bs-gutter-x) * 0.5);
  padding-left: calc(var(--bs-gutter-x) * 0.5);
  margin-top: var(--bs-gutter-y);
}
.card-body {
  flex: 1 1 auto;
  padding: 1rem 1rem;
}
</style>
