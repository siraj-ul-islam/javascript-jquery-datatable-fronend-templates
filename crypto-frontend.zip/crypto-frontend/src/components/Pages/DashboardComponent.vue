<template>
  <div class="page-wrapper">
    <Loading
      :active.sync="isLoading"
      :can-cancel="false"
      :is-full-page="fullPage"
    ></Loading>
    <div class="page-content">
      <div class="card shadow-none bg-transparent border-bottom border-2">
        <div class="card-header">
          <!-- <div class="row align-items-center" style="padding-right: 50px"> -->
          <!-- <div class="col-md-auto"> -->
          <h4 class="mb-12 mb-md-0">Audience Overview</h4>
        </div>
        <div class="card-body w-100">
          <div class="row justify-content-between">
            <!--  <div class="col">
                           <button type="button" class="btn btn-light px-3">Comparison</button>
                           </div> -->
            <!-- <div class="col"> -->
            <div class="row w-auto">
              <div class="d-flex">
                <div class="btn">
                  <button type="button" class="btn btn-light px-3">Week</button>
                </div>
                <div class="btn">
                  <button type="button" disabled class="btn btn-light px-3">
                    Month
                  </button>
                </div>
                <div class="btn">
                  <button type="button" disabled class="btn btn-light px-3">
                    3 Month
                  </button>
                </div>
                <div class="btn">
                  <button type="button" disabled class="btn btn-light px-3">
                    6 Month
                  </button>
                </div>
                <div class="btn">
                  <button type="button" disabled class="btn btn-light px-3">
                    Year
                  </button>
                </div>
              </div>
            </div>
            <div class="">
              <form class="d-flex">
                <div class="d-flex">
                  <label
                    for="inputFromDate"
                    class="col-form-label inputFromDate"
                    >Start Date</label
                  >
                  <div class="col-form-label">
                    <datepicker
                      placeholder="Select Date"
                      v-model="startDate"
                      @selected="checkDateRange('startDate')"
                    ></datepicker>
                  </div>
                </div>
                <div class="d-flex">
                  <label for="inputToDate" class="col-form-label inputFromDate"
                    >End Date</label
                  >
                  <div class="col-form-label">
                    <datepicker
                      placeholder="Select Date"
                      v-model="endDate"
                      @selected="fetchData('endDate')"
                    ></datepicker>
                    <!-- <input type="date" class="form-control" id="inputToDate" /> -->
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-1 col-sm-8 text-center" v-show="data.length">
          <div v-show="modelName == 'all' || modelName == 'sarimax'">
            <div class="text-title">SARIMAX</div>
            <div class="green-text" v-show="sarimax_signal">-BUY-</div>
            <div class="yellow-text" v-show="!sarimax_signal">-SELL-</div>
          </div>
          <div v-show="modelName == 'all' || modelName == 'lstm'">
            <div class="text-title">LSTM</div>
            <div class="green-text" v-show="lstm_signal">-BUY-</div>
            <div class="yellow-text" v-show="!lstm_signal">-SELL-</div>
          </div>
        </div>
        <div class="col-md-11 col-sm-12">
          <div class="">
            <div class="col-sm-12">
              <div class="col-sm-12">
                <div id="chartDetails"></div>

                <div id="chart">
                  <!-- <apexchart
              type="line"
              height="350"
              :options="chartOptions"
              :series="series"
            ></apexchart> -->
                </div>
                <div
                  class="apexcharts-legend apexcharts-align-center apx-legend-position-bottom"
                >
                  <div
                    @click="setModelName('sarimax')"
                    :class="[
                      modelName == 'all' || modelName == 'sarimax'
                        ? ''
                        : 'reduce_opacity',
                    ]"
                    class="apexcharts-legend-series"
                    style="padding: 10px"
                  >
                    <span
                      style="
                        width: 15px;
                        height: 15px;
                        background-color: yellow;
                        margin-right: 5px;
                      "
                    ></span>
                    SARIMAX
                  </div>
                  <div
                    @click="setModelName('lstm')"
                    :class="[
                      modelName == 'all' || modelName == 'lstm'
                        ? ''
                        : 'reduce_opacity',
                    ]"
                    class="apexcharts-legend-series"
                    style="padding: 10px"
                  >
                    <span
                      style="
                        width: 15px;
                        height: 15px;
                        background-color: white;
                        margin-right: 5px;
                      "
                    ></span>
                    LSTM
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- <div class="row new-chart">
        <div class="col-md-1 col-sm-12 text-center">
          <div class="green-text">-BUY-</div>
          <div class="yellow-text">-SELL-</div>
        </div>
        <div class="col-md-11 col-sm-12">New Charts</div>
      </div> -->

      <div class="row row-cols-1 row-cols-md-1 row-cols-xl-2 new-chart">
        <div class="col-md-12">
          <h4 class="heading">Comparison as of {{initial_date}}</h4>
        </div>
      </div>
      <div class="row row-cols-1 row-cols-md-2 row-cols-xl-2 new-chart p20">
        <table style="width: 80%">
          <tr>
            <th>Date</th>
            <th v-for="date in headers" :key="date">{{ date }}</th>
          </tr>
          <tr v-for="row in table_data" :key="row.key">
            <td>{{ row.key }}</td>
            <td v-for="(data, index) in row.data" :key="index">
              <div v-html="checkButtonToDisplay(data)"></div>
            </td>
          </tr>
        </table>
      </div>

      <div class="col-md-3 heading">
        <h4 class="mb-3 mb-md-0">Comparing Overview</h4>
      </div>
      <div class="row row-cols-1 row-cols-md-2 row-cols-xl-2">
        <div class="col">
          <div class="card radius-10">
            <div class="card-body">
              <apexchart
                type="bar"
                height="350"
                :options="chartOptions1"
                :series="series1"
              ></apexchart>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card radius-10">
            <div class="card-body">
              <apexchart
                type="bar"
                height="350"
                :options="chartOptions2"
                :series="series2"
              ></apexchart>
            </div>
          </div>
        </div>
      </div>
      <!--end row-->
      <div class="row row-cols-1 row-cols-md-2 row-cols-xl-2">
        <div class="col d-flex">
          <div class="card radius-10 w-100">
            <div
              class="card-body"
              style="max-height: 400px; overflow-y: auto; overflow-x: hidden"
            >
              <apexchart
                type="bar"
                :options="chartOptions3"
                :series="series3"
              ></apexchart>
            </div>
          </div>
        </div>
        <div class="col d-flex">
          <div class="card radius-10 w-100">
            <div class="card-body" style="text-align: -webkit-center">
              <h5 v-show="series4.length || series5.length">
                Price Prediction Accuracy Percentage
              </h5>
              <div
                :class="[modelName == 'all' ? 'float-left' : '']"
                v-show="
                  (modelName == 'all' || modelName == 'lstm') && series4.length
                "
              >
                <h6>LSTM</h6>
                <apexchart
                  ref="pieChartLSTM"
                  type="donut"
                  width="300"
                  height="300"
                  :options="chartOptions4"
                  :series="series4"
                ></apexchart>
              </div>
              <div
                :class="[modelName == 'all' ? 'float-right' : '']"
                v-show="
                  (modelName == 'all' || modelName == 'sarimax') &&
                  series5.length
                "
              >
                <h6>SARIMAX</h6>
                <apexchart
                  type="donut"
                  width="300"
                  height="300"
                  :options="chartOptions4"
                  :series="series5"
                ></apexchart>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--end row-->
    </div>
  </div>
</template>

<script>
import axios from "../../services/userApi";
import swal from "sweetalert2";
import { mapState } from "vuex";
import Loading from "vue-loading-overlay";
import "vue-loading-overlay/dist/vue-loading.css";
import VueApexCharts from "vue-apexcharts";
import Datepicker from "vuejs-datepicker/dist/vuejs-datepicker.esm.js";
import { createChart, CrosshairMode } from "lightweight-charts";

export default {
  name: "DashboardComponent",
  computed: {
    ...mapState("productionModels", {
      modelName: (state) => state.modelName,
    }),
  },
  data() {
    return {
      height: 600,
      sarimax_signal: false,
      lstm_signal: false,
      headers: [],
      table_data: [],
      initial_date: '',
      histogramLSTM: [],
      histogramSARIMAX: [],
      chart: null,
      fullPage: true,
      isLoading: false,
      startDate: null,
      queryStartDate: null,
      endDate: null,
      queryEndDate: null,
      data: [],
      lstm: [],
      sarimax: [],
      series5: [],
      series4: [],
      chartOptions4: {
        chart: {
          foreColor: "rgba(255, 255, 255, 0.65)",
          type: "pie",
        },
        labels: ["Accuracy", "Error"],
        theme: {
          monochrome: {
            enabled: true,
          },
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -5,
            },
          },
        },
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex];
            return [name, val.toFixed(1) + "%"];
          },
          style: {
            fontSize: "14px",
            fontFamily: "Helvetica, Arial, sans-serif",
            colors: ["#000"],
          },
        },
        legend: {
          show: false,
        },
        colors: [
          function () {
            return "#26A69A";
          },
          function () {
            return "#ef5350";
          },
        ],
        tooltip: {
          enabled: false,
        },
      },
      series3: [],
      chartOptions3: {
        chart: {
          foreColor: "rgba(255, 255, 255, 0.65)",
          type: "bar",
          height: 600,
        },
        title: {
          text: "Features Priority",
          align: "left",
          style: {
            fontSize: "16px",
            color: "#fff",
          },
        },
        plotOptions: {
          bar: {
            borderRadius: 4,
            // columnWidth: '50%',
            barHeight: "80%",
            horizontal: true,
          },
        },
        dataLabels: {
          enabled: false,
        },
        xaxis: {
          categories: [],
        },
        yaxis: {
          min: -1,
          max: 0.9,
        },
        colors: ["#FFC40A"],
      },
      series2: [],
      chartOptions2: {
        chart: {
          foreColor: "rgba(255, 255, 255, 0.65)",
          type: "bar",
          height: 350,
        },
        title: {
          text: "Error Values",
          align: "left",
          style: {
            fontSize: "16px",
            color: "#fff",
          },
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "75%",
            endingShape: "rounded",
          },
        },
        dataLabels: {
          enabled: false,
        },
        xaxis: {
          categories: [],
        },
        yaxis: {
          title: {
            text: "Value",
          },
          labels: {
            formatter: (value) => {
              return value.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            },
          },
        },
        colors: ["#26A69A", "#FFC40A"],
        fill: {
          opacity: 1,
        },
      },
      series1: [],
      chartOptions1: {
        chart: {
          foreColor: "rgba(255, 255, 255, 0.65)",
          type: "bar",
          height: 350,
        },
        title: {
          text: "Bitcoin Price Forecast",
          align: "left",
          style: {
            fontSize: "16px",
            color: "#fff",
          },
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: "55%",
            endingShape: "rounded",
          },
        },
        dataLabels: {
          enabled: false,
        },
        stroke: {
          show: true,
          width: 2,
          colors: ["transparent"],
        },
        xaxis: {
          categories: [],
        },
        yaxis: {
          title: {
            text: "Price",
          },
          labels: {
            formatter: (value) => {
              return value.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            },
          },
        },
        colors: ["#26A69A", "#FFC40A", "#fff"],
        fill: {
          opacity: 1,
        },
      },
      series: [
        {
          name: "Actual",
          data: [10, 41, 35, 51, 49, 62, 69],
        },
        {
          name: "Predicted",
          data: [7, 50, 25, 41, 59, 72, 79],
        },
      ],
      chartOptions: {
        chart: {
          foreColor: "rgba(255, 255, 255, 0.65)",
          height: 400,
          type: "line",
          zoom: {
            enabled: false,
          },
          toolbar: {
            show: true,
          },
          dropShadow: {
            enabled: true,
            top: 3,
            left: 14,
            blur: 4,
            opacity: 0.1,
          },
        },
        dataLabels: {
          enabled: false,
        },
        stroke: {
          width: 5,
          curve: "smooth",
        },
        title: {
          text: "Bitcoin Price Forecast",
          align: "left",
          style: {
            fontSize: "16px",
            color: "#fff",
          },
        },
        grid: {
          show: true,
          borderColor: "rgba(255, 255, 255, 0.12)",
          strokeDashArray: 4,
        },
        xaxis: {
          categories: [
            "02/01/2022",
            "02/02/2022",
            "02/31/2022",
            "02/04/2022",
            "02/05/2022",
            "02/06/2022",
            "02/07/2022",
          ],
        },
        toolbar: {
          colors: "#000",
        },
        fill: {
          type: "gradient",
          gradient: {
            shade: "light",
            gradientToColors: ["#fff"],
            shadeIntensity: 1,
            type: "horizontal",
            opacityFrom: 1,
            opacityTo: 1,
            stops: [0, 100, 100, 100],
          },
        },
        colors: ["#fff", "#FFC40A"],
        yaxis: {
          title: {
            text: "Price",
          },
        },
      },
    };
  },
  components: {
    Loading,
    apexchart: VueApexCharts,
    Datepicker,
  },
  methods: {
    checkButtonToDisplay: function (val) {
      return val == true
        ? '<div class="green-text">-BUY-</div>'
        : '<div class="yellow-text">-SELL-</div>';
    },
    setModelName(val = "all") {
      this.$store.dispatch("productionModels/changeModelName", val);
    },
    async fetchData() {
      let future_date = new Date();
      future_date.setDate(future_date.getDate() + 180);
      let d = null;
      this.$nextTick(() => {
        d = new Date(this.endDate);
        if (d <= future_date) {
          this.queryEndDate = `${d.getFullYear()}-${
            d.getMonth() + 1
          }-${d.getDate()}`;
          this.chartOptions2.xaxis.categories = [];
          this.isLoading = true;
          this.createChartsData();
        } else {
          swal.fire({
            title: "Please select a range of a maximum of 6 months.",
            buttonsStyling: false,
            customClass: {
              confirmButton: "btn btn-success btn-fill",
            },
          });
        }
        return true;
      });
      // console.log("d is: " + d);
      // console.log("future is : " + future_date);
    },
    checkDateRange() {
      this.$nextTick(() => {
        let d = new Date(this.startDate);
        this.queryStartDate = `${d.getFullYear()}-${
          d.getMonth() + 1
        }-${d.getDate()}`;
      });
    },
    createLightChart() {
      var container = document.getElementById("chart");
      container.innerHTML = "";
      this.chart = createChart(container, {
        height: this.height,
        leftPriceScale: {
          visible: true,
          borderColor: "rgba(197, 203, 206, 1)",
        },
        layout: {
          backgroundColor: "#151313",
          textColor: "#a7a7a7",
        },
        grid: {
          horzLines: {
            color: "#000",
          },
          vertLines: {
            color: "#000",
          },
        },
        crosshair: {
          mode: CrosshairMode.Normal,
        },
        rightPriceScale: {
          visible: false,
          scaleMargins: {
            top: 0.3,
            bottom: 0.25,
          },
          borderVisible: false,
        },
      });

      let histogram = this.chart.addHistogramSeries({
        color: "#fff",
        priceFormat: {
          type: "volumes",
        },
        priceScaleId: "",
        scaleMargins: {
          top: 0.8,
          bottom: 0,
        },
        // base: 2,
      });
      if (this.modelName == "lstm") {
        histogram.setData(this.histogramLSTM);
      } else if (this.modelName == "sarimax") {
        histogram.setData(this.histogramSARIMAX);
      }
      this.chart.timeScale().fitContent();
      var candleSeries = this.chart.addCandlestickSeries();
      candleSeries.setData(this.data);
      if (this.modelName == "all" || this.modelName == "lstm") {
        var smaLine = this.chart.addLineSeries({
          color: "#fff",
          lineWidth: 2,
        });
        smaLine.setData(this.lstm);
      }
      if (this.modelName == "all" || this.modelName == "sarimax") {
        var smaLine1 = this.chart.addLineSeries({
          color: "rgb(255, 196, 10)",
          lineWidth: 2,
        });
        smaLine1.setData(this.sarimax);
      }

      var legend = document.getElementById("chartDetails");
      legend.style.display = "block";
      legend.style.paddingLeft = 70 + "px";
      legend.style.top = 5 + "px";
      legend.style.wordSpacing = 20 + "px";
      let th = this;
      function setLegendText(sarimax, lstm, data) {
        if (sarimax !== undefined) {
          sarimax = (Math.round(sarimax * 100) / 100)
            .toFixed(2)
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        } else {
          sarimax = "00.00";
        }
        if (lstm !== undefined) {
          lstm = (Math.round(lstm * 100) / 100)
            .toFixed(2)
            .replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        } else {
          lstm = "00.00";
        }
        let html = "";
        if (th.modelName == "all" || th.modelName == "sarimax") {
          html +=
            'SARIMAX <span id="sarimax" style="color:rgba(4, 111, 232, 1)">' +
            sarimax +
            "</span> ";
        }
        if (th.modelName == "all" || th.modelName == "lstm") {
          html +=
            'LSTM <span id="lstm" style="color:rgba(4, 111, 232, 1)">' +
            lstm +
            "</span> ";
        }
        if (data !== undefined && data.close != undefined) {
          html +=
            'Close <span style="color:rgba(4, 111, 232, 1)">' +
            data.close.replace(/\B(?=(\d{3})+(?!\d))/g, ",") +
            "</span> ";
        }
        if (data !== undefined && data.high != undefined) {
          html +=
            'High <span style="color:rgba(4, 111, 232, 1)">' +
            data.high.replace(/\B(?=(\d{3})+(?!\d))/g, ",") +
            "</span> ";
        }
        if (data !== undefined && data.low != undefined) {
          html +=
            'Low <span style="color:rgba(4, 111, 232, 1)">' +
            data.low.replace(/\B(?=(\d{3})+(?!\d))/g, ",") +
            "</span> ";
        }
        if (data !== undefined && data.open != undefined) {
          html +=
            'Open <span style="color:rgba(4, 111, 232, 1)">' +
            data.open.replace(/\B(?=(\d{3})+(?!\d))/g, ",") +
            "</span>";
        }
        // }
        legend.innerHTML = html;
      }
      setLegendText(
        this.sarimax.length ? this.sarimax[this.sarimax.length - 1].value : "",
        this.lstm.length ? this.lstm[this.lstm.length - 1].value : "",
        this.data[this.data.length - 1] ?? ""
      );
      if (this.modelName == "all") {
        this.chart.subscribeCrosshairMove((param) => {
          setLegendText(
            param.seriesPrices.get(smaLine1),
            param.seriesPrices.get(smaLine),
            param.seriesPrices.get(candleSeries)
          );
        });
      } else {
        if (this.modelName == "lstm") {
          this.chart.subscribeCrosshairMove((param) => {
            setLegendText(
              undefined,
              param.seriesPrices.get(smaLine),
              param.seriesPrices.get(candleSeries)
            );
          });
        } else {
          this.chart.subscribeCrosshairMove((param) => {
            setLegendText(
              param.seriesPrices.get(smaLine1),
              undefined,
              param.seriesPrices.get(candleSeries)
            );
          });
        }
      }
    },
    async createChartsData() {
      let features = await axios.makeApiCall(
        "get",
        "/features/get/correlations"
      );
      let f = [];
      let featureCategories = [];
      // console.log(features.data);
      features.data.forEach((feature) => {
        featureCategories.push(feature.feature_name);
        f.push(feature.feature_value);
      });
      this.chartOptions3 = {
        ...this.chartOptions3,
        ...{
          xaxis: {
            categories: featureCategories,
          },
        },
      };
      this.series3 = [{ data: f }];
      let dt = await axios.makeApiCall(
        "get",
        `forecast/get/${this.queryStartDate ?? "2022-03-01"}/${
          this.queryEndDate ?? "2022-03-08"
        }`,
        "",
        "",
        ""
      );
      // console.log(dt.data);
      let errorQuery = `errors/get/errors/${
        this.queryStartDate ?? "2022-03-01"
      }/${this.queryEndDate ?? "2022-03-08"}`;
      if (this.modelName != "all") {
        errorQuery += `?model_name=${this.modelName}`;
      }
      // console.log(errorQuery);
      let errors = await axios.makeApiCall("get", errorQuery, "", "", "");
      let accuracy = null;
      try {
        accuracy = await axios.makeApiCall(
          "get",
          `errors/get/accuracy/${this.queryStartDate ?? "2022-03-01"}/${
            this.queryEndDate ?? "2022-03-08"
          }`
        );
        // console.log(accuracy);
      } catch (e) {
        console.log(e);
      }
      // console.log(accuracy.data);
      if (!accuracy.data.detail && accuracy.data) {
        let pie1 = [];
        let pie2 = [];
        accuracy.data.forEach((ac) => {
          // console.log(ac);
          switch (ac.model) {
            case "lstm_prediction":
              pie1.push(ac.Accuracy);
              pie1.push(ac.Error);
              break;
            case "sarimax_prediction":
              pie2.push(ac.Accuracy);
              pie2.push(ac.Error);
              break;
            default:
              break;
          }
        });
        this.series4 = [];
        this.series5 = [];
        if (this.modelName == "all" || this.modelName == "lstm") {
          this.series4 = pie1;
        }
        if (this.modelName == "all" || this.modelName == "sarimax") {
          this.series5 = pie2;
        }
      }
      // let open = 40000.00;
      let actual = [];
      let lstm = [];
      let sarimax = [];
      let timeCategories = [];
      this.chartOptions1.xaxis.categories = [];
      this.lstm = [];
      this.sarimax = [];
      this.data = [];
      this.histogramLSTM = [];
      this.histogramSARIMAX = [];
      this.headers = [];
      let lstm_errors = [];
      let sarimax_errors = [];
      // console.log(dt.data[dt.data.length - 1].lstm_prediction);
      if (dt.data.length) {
        dt.data[0].lstm_prediction_status != "Buy"
          ? (this.lstm_signal = false)
          : (this.lstm_signal = true);
        dt.data[0].sarimax_prediction_status != "Buy"
          ? (this.sarimax_signal = false)
          : (this.sarimax_signal = true);
        let t = new Date(dt.data[0].future_date);
        t.setDate(t.getDate() - 1);
        this.initial_date = t.getFullYear() +'-'+ (t.getMonth()+1) +'-'+ t.getDate(); 
      }
      dt.data.forEach((d) => {
        let t = d.future_date.split("-");
        let time = {
          day: parseInt(t[2]),
          month: parseInt(t[1]),
          year: parseInt(t[0]),
        };
        if (d.actual_price) {
          this.data.push({
            time: time,
            open: d.open_price ? d.open_price.toFixed(2) : "",
            high: d.high_price ? d.high_price.toFixed(2) : "",
            low: d.low_price ? d.low_price.toFixed(2) : "",
            close: d.actual_price ? d.actual_price.toFixed(2) : "",
          });
        }
        this.headers.push(`${t[0]}-${t[1]}-${t[2]}`);
        lstm_errors.push(d.lstm_prediction_status == "Buy" ? true : false);
        sarimax_errors.push(
          d.sarimax_prediction_status == "Buy" ? true : false
        );
        this.histogramLSTM.push({
          time: time,
          value: d.lstm_prediction_error,
          color: "rgba(255,255,255, 0.3)",
        });
        this.histogramSARIMAX.push({
          time: time,
          value: d.sarimax_prediction_error,
          color: "rgba(255,255,255, 0.3)",
        });
        // `${parseInt(t[0])}-${parseInt(t[1])}-${t[2]}`
        this.sarimax.push({
          time: time,
          value: d.sarimax_prediction.toFixed(2),
        });
        this.lstm.push({
          time: time,
          value: d.lstm_prediction.toFixed(2),
        });
        actual.push(d.actual_price);
        if (this.modelName == "all" || this.modelName == "lstm") {
          lstm.push(d.lstm_prediction.toFixed(2));
        }
        if (this.modelName == "all" || this.modelName == "sarimax") {
          sarimax.push(d.sarimax_prediction.toFixed(2));
        }
        timeCategories.push(`${t[1]}/${t[2]}/${t[0]}`);
        // open = d.actual_price;
      });
      this.table_data = [];
      if (this.modelName == "all" || this.modelName == "lstm") {
        this.table_data.push({ key: "LSTM", data: lstm_errors });
      }
      if (this.modelName == "all" || this.modelName == "sarimax") {
        this.table_data.push({ key: "SARIMAX", data: sarimax_errors });
      }
      // console.log(this.histogram);
      this.chartOptions1 = {
        ...this.chartOptions1,
        ...{
          xaxis: {
            categories: timeCategories,
          },
        },
      };
      // console.log(timeCategories);
      let d = [];
      d.push({
        name: "Actual",
        data: actual,
      });
      if (this.modelName == "all" || this.modelName == "sarimax") {
        d.push({
          name: "SARIMAX",
          data: sarimax,
        });
      }
      if (this.modelName == "all" || this.modelName == "lstm") {
        d.push({
          name: "LSTM",
          data: lstm,
        });
      }
      this.series1 = d;
      let rmse = [];
      let mae = [];
      if (!errors.data.detail && errors.data) {
        errors.data.forEach((error) => {
          if (this.modelName == "all") {
            rmse.push(error.RMSE);
            mae.push(error.MAE);
          } else if (this.modelName == error.model.split("_")[0]) {
            rmse.push(error.RMSE);
            mae.push(error.MAE);
          }
        });
      }
      if (this.modelName == "all") {
        this.chartOptions2 = {
          ...this.chartOptions2,
          ...{
            xaxis: {
              categories: ["LSTM", "Sarimax"],
            },
          },
        };
      }
      if (this.modelName == "sarimax") {
        this.chartOptions2 = {
          ...this.chartOptions2,
          ...{
            xaxis: {
              categories: ["Sarimax"],
            },
          },
        };
      }
      if (this.modelName == "lstm") {
        this.chartOptions2 = {
          ...this.chartOptions2,
          ...{
            xaxis: {
              categories: ["LSTM"],
            },
          },
        };
      }
      this.series2 = [
        {
          name: "RMSE",
          data: rmse,
        },
        {
          name: "MAE",
          data: mae,
        },
      ];
      this.createLightChart();
      this.isLoading = false;
    },
  },
  mounted() {
    var container = document.getElementById("chart");
    this.chart = createChart(container, {
      width: this.width,
      height: this.height,
      rightPriceScale: {
        visible: false,
        borderColor: "rgba(197, 203, 206, 1)",
      },
      leftPriceScale: {
        visible: true,
        borderColor: "rgba(197, 203, 206, 1)",
      },
      layout: {
        backgroundColor: "#151313",
        textColor: "#a7a7a7",
      },
      grid: {
        horzLines: {
          color: "#000",
        },
        vertLines: {
          color: "#000",
        },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
      },
      timeScale: {
        borderColor: "rgba(197, 203, 206, 1)",
      },
      handleScroll: {
        vertTouchDrag: true,
      },
    });
  },
  watch: {
    modelName: function (modelName) {
      this.chartOptions2.xaxis.categories = [];
      this.histogram = [];
      console.log(modelName);
      this.isLoading = true;
      this.createChartsData();
    },
  },
};
</script>
<style>
.apexcharts-tooltip {
  color: #000;
  background: #f3f3f3;
}
.apexcharts-tooltip-marker {
  display: none;
}
.vdp-datepicker__calendar {
  background: #000 !important;
}
input,
textarea {
  background-color: transparent;
  border: solid 1px #fff6;
  border-radius: 2px;
  padding: 5px;
  color: #fff;
  font-size: 13px;
}
::placeholder {
  color: red !important;
}
.float-left {
  float: left;
}
.float-right {
  float: right;
}
.text-center {
  text-align: center;
}
.green-text {
  padding: 5px;

  color: #ffffff;
  padding: 5px;
  background: #1ddb1d;
  border-radius: 50px;
  margin-bottom: 10px;
}
.yellow-text {
  color: #ffffff;
  padding: 5px;
  margin-bottom: 10px;
  background: #ef5350;
  border-radius: 50px;
}
.new-chart {
  margin-bottom: 20px;
  margin-top: 20px;
}

tbody,
td,
tfoot,
th,
thead,
tr {
  border-width: 1px;
  padding: 5px;
}
.inputFromDate {
  margin-right: 8px;
  margin-left: 8px;
}
.text-title {
  padding: 5px;
}
.p20 {
  padding: 20px;
}
.reduce_opacity {
  opacity: 0.45;
}
</style>
