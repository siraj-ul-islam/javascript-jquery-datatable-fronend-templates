<template>
  <header class="main-header-wrapper">
    <div class="main-header-inner">
      <div class="header-left">
        <span @click="emitSidebarToggleEvent" class="fas fa-bars"></span>
      </div>
      <div class="header-right">
        <div class="noti-bell">
          <i class="fas fa-bell"></i>
          <span>0</span>
        </div>
        <div class="profile-dropdown">
          <div class="dropdown">
                <span class="dropdown-toggle" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" @click="toggleSubMenu">
                  Max Syed <i class="fas fa-angle-down"></i> <img src="../../assets/images/profile-img.png" alt="img">
                </span>
            <ul class="dropdown-menu my-custom-sub-menu-class" :class="{ 'show': subMenu }"
                aria-labelledby="dropdownMenuButton1">
              <li><a href="#"><i class="far fa-user-circle"></i> Profile</a></li>
              <li><a href="#"><i class="fas fa-cog"></i> Setting</a></li>
              <li v-on:click="logout()"><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'Header',
  data (){
    return{
      subMenu: false,
    }
  },
  methods:{
    async logout(){
      let response = await this.$store.dispatch('auth/logout');
      console.log('response is: '+response);
      if(response){
        this.$router.push('/login')
      }
    },
    toggleSubMenu(){
      // if(this.subMenu == false){
      //   this.subMenu = true;
      // }else{
      //   this.subMenu = false;
      // }
      console.log('in header toggle menu');
      this.subMenu = !this.subMenu;
    },
    emitSidebarToggleEvent(){
      this.$emit('sidebarToggling')
    }
  }
}
</script>

<style>
.my-custom-sub-menu-class{
  position: absolute;
  inset: 0px auto auto 0px;
  margin: 0px;
  transform: translate(-47px, 31px);
}
</style>