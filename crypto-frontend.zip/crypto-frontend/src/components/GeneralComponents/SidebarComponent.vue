<template>
  <!-- <div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
      <div class="main-menu-content">
        
      </div>
    </div> -->
  <div class="sidebar-wrapper" data-simplebar="true">

    <div class="sidenav">
  <a href="#about">About</a>
  <a href="#services">Services</a>
  <a href="#clients">Clients</a>
  <a href="#contact">Contact</a>
  <button class="dropdown-btn">Dropdown 
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="#">Link 1</a>
    <a href="#">Link 2</a>
    <a href="#">Link 3</a>
  </div>
  <a href="#contact">Search</a>
</div>

    <div class="sidebar-header">
      <div>
        <img src="../../assets/images/logo.png" class="logo-icon" alt="logo" />
      </div>
    </div>
    <!-- navigation -->
    <ul class="metismenu" id="menu">
      <li @click="displaySubMenu()">
        <a href="javascript:;" class="">
          <div class="parent-icon"><i class="bx bx-category"></i></div>
          <div class="menu-title">Models</div>
        </a>
        <ul class="metismenu-sub" :class="[display ? 'showing' : 'hiding']">
          <li>
            <a href="javascript:;" class="" @click="setModelName('all')">
              <div class="parent-icon"><i class="bx bx-category"></i></div>
              <div class="menu-title">ALL</div>
            </a>
          </li>
          <li>
            <a href="javascript:;" class="" @click="setModelName('sarimax')">
              <div class="parent-icon"><i class="bx bx-category"></i></div>
              <div class="menu-title">SARIMAX</div>
            </a>
          </li>
          <li>
            <a href="javascript:;" class="" @click="setModelName('lstm')">
              <div class="parent-icon"><i class="bx bx-category"></i></div>
              <div class="menu-title">LSTM</div>
            </a>
          </li>
        </ul>
      </li>
    </ul>
    <!--end navigation-->
  </div>
  
</template>

<script>
export default {
  name: "SidebarComponent",
  data(){
    return{
      display: false
    }
  },
  methods:{
    setModelName(val='all'){
      this.$store.dispatch('productionModels/changeModelName',val);
    },
    displaySubMenu(){
      this.display = !this.display;
    }
  },
  mounted(){
    this.setModelName()
  }
};
</script>
<style scoped>
.hiding{
  display:none;
}
.showing{
  display:block;
}
</style>


