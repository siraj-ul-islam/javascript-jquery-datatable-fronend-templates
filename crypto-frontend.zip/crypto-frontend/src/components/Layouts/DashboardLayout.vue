<template>
  <div class="wrapper">
    <!-- <Header v-on:sidebarToggling="toggleSidebar"></Header> -->
    <Sidebar></Sidebar>
    <zoom-center-transition :duration="200" mode="out-in">
      <!-- your content here -->
      <router-view></router-view>
    </zoom-center-transition>
    <Footer></Footer>
  </div>
</template>

<script>

import Sidebar from "../GeneralComponents/SidebarComponent";
import { ZoomCenterTransition } from "vue2-transitions";
import Footer from '../GeneralComponents/FooterComponent.vue';

export default {
  name: "DashboardLayout",
  data() {
    return {
      showSidebar: false,
    };
  },
  components: {
    Footer,
    Sidebar,
    ZoomCenterTransition
  },
  methods: {
    toggleSidebar() {
      this.showSidebar = !this.showSidebar;
    },
  },
};
</script>
