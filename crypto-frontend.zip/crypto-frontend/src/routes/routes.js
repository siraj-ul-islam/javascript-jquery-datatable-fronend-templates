import DashboardLayout from '../components/Layouts/DashboardLayout';
// const DataAnalysis = () => import('../components/Pages/DataAnalysis');
const LoginComponent = () => import('../components/Pages/LoginComponent');
const DashboardComponent = () => import('../components/Pages/DashboardComponent');
// const Job = () => import('../components/Pages/Job');

const routes = [
    {
        path: '/',
        name: 'Dashboard',
        redirect: '/dashboard'
    },
    {
        path: '/login',
        name: 'login',
        component : LoginComponent,
    },
    {
        path: '/dashboard',
        name: 'Dashboard Layout',
        component : DashboardLayout,
        children: [
            {
                path: '/',
                name: 'Dashboard',
                components: { default: DashboardComponent },

            },
            // {
            //     path: 'dataanalysis',
            //     name: 'DataAnalysis',
            //     components: { default: DataAnalysis },
            // },
            // {
            //     path: 'job/:id',
            //     name: 'Job',
            //     components: { default: Job },
            // }
        ]
    },
];

export default routes;
