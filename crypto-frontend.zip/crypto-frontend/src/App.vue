<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>


export default {
  name: 'App'
}
</script>

<style>
@import './assets/styles/style.css';
@import './assets/styles/bootstrap.min.css';
@import './assets/styles/bootstrap-extended.css';
@import './assets/styles/icons.css';

</style>
