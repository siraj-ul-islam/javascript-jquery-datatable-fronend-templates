import axios from '../util/axios';

class Axios {
  makeApiCall(api_type,url,parameters = '',data = null,multiPart=false){
    axios.interceptors.request.use(
      function(config) {
          config.headers["Authorization"] = '';
          config.headers["Content-Type"] = 'www-form-urlencoded';
        const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJha3VsYSIsImV4cCI6MTY0OTQyMDE2N30.nHOXjN6h52gtkRx8dJD-aM8GloI8z52CKUYoDFGLUek';
        if (token && multiPart) {
          config.headers["Authorization"] = 'Bearer ' + token;
        }else{
          config.headers["Authorization"] = 'Bearer ' + token;
        }
        return config;
      },
      function(error) {
        return Promise.reject(error);
      }
    );
    return axios({
      method: api_type,
      url: url+parameters,
      data: data,
    });
  }
}

export default new Axios();

// if(multiPart) {
//   axios.defaults.headers.common = {
//     'Authorization': 'bearer '+localStorage.getItem('token'),
//     'Content-Type': 'multipart/form-data'
//   };
// }else{
//   axios.defaults.headers.common = {'Authorization': 'bearer '+localStorage.getItem('token')};
// }
